import axios from "axios";

const API_KEY =
  "p6AKm1A+wK5iP28Zaa/HIoqAe1GIazQGg2Ot90cyOC4IIut3wSujFFUI13LvNqgpp6LROo8h1i4ZnDA8xyJumdYks/JEu2IHXPFp87tLZxMoABLZJXXgv9IIf8BlwElO";
const BASE_URL = "https://api.vimeo.com";

export const fetchVimeoVideos = async () => {
  const response = await axios.get(`${BASE_URL}/channels/juneautek/videos`, {
    headers: {
      Authorization: `Bearer ${API_KEY}`,
    },
  });
  return response.data.data;
};
