import axios from "axios";

const API_KEY = "AIzaSyAM10E7tZLTqhPbX1OtcCsBXe5roaS8-xw";
const BASE_URL = "https://www.googleapis.com/youtube/v3";

export const fetchYouTubeVideos = async (playlistId) => {
  const response = await axios.get(`${BASE_URL}/playlistItems`, {
    params: {
      part: "snippet",
      playlistId: playlistId,
      maxResults: 10,
      key: API_KEY,
    },
  });
  return response.data.items;
};
