import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { fetchYouTubeVideos } from '../services/youtube';
import { fetchVimeoVideos } from '../services/vimeo';

const Category = () => {
  const { id } = useParams();
  const [videos, setVideos] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      if (id === 'youtube') {
        const result = await fetchYouTubeVideos('PLqBvKv8OhaTjJEYTUs8zhwhew3mUM4eYP'); // Use your YouTube playlist ID
        setVideos(result);
      } else if (id === 'vimeo') {
        const result = await fetchVimeoVideos();
        setVideos(result);
      }
    };
    fetchData();
  }, [id]);

  return (
    <div style={{ padding: '20px', backgroundColor: '#121212', color: '#fff' }}>
      <h2>{id === 'youtube' ? 'YouTube' : 'Vimeo'} Videos</h2>
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {videos.map((video, index) => (
          <div key={index} style={{ margin: '10px', width: '300px' }}>
            <h3>{video.snippet?.title || video.name}</h3>
            <iframe
              src={id === 'youtube' ? `https://www.youtube.com/embed/${video.snippet.resourceId.videoId}` : `https://player.vimeo.com/video/${video.uri.split('/').pop()}`}
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              all
