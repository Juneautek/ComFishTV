import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div
      style={{
        textAlign: "center",
        padding: "20px",
        color: "#fff",
        backgroundColor: "#121212",
      }}
    >
      <h1>Commercial Fishing Film Festival</h1>
      <ul style={{ listStyle: "none", padding: "0" }}>
        <li>
          <Link to="/category/youtube" style={{ color: "#61dafb" }}>
            YouTube Videos
          </Link>
        </li>
        <li>
          <Link to="/category/vimeo" style={{ color: "#61dafb" }}>
            Vimeo Videos
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default Home;
